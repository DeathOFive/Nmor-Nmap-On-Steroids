# Nmor — Nmap on Roids

A raw-socket port scanner written in Rust, built to be a faster, cleaner,
modern alternative to Nmap, with the same command-line muscle memory.

## Install (Linux, including WSL2 — x86_64)

No Rust, no compiling, no dependencies to install. Just:

```bash
./install.sh
```

This copies the prebuilt `nmor` binary to `/usr/local/bin/nmor` and grants
it `CAP_NET_RAW` via `setcap`, so you can run SYN/ACK scans **without
typing `sudo` every time** — already a step up from a default Nmap install.

If `setcap` isn't available (rare), the installer tells you and you can
just prefix commands with `sudo` instead.

## Quick start

```bash
nmor -sS scanme.nmap.org -p 22,80,443        # SYN scan (needs root or setcap)
nmor -sT scanme.nmap.org -p 1-1000           # TCP connect scan (no root ever needed)
nmor -sA 192.168.1.1 -p 1-1000               # ACK scan (firewall mapping)
nmor -sSV 192.168.1.0/24 -p 1-1000 --reason  # SYN scan + banner grab + reasons
nmor -sS 10.0.0.1 -T4 -p- -oA myscan         # all ports, aggressive timing, all output formats
```

If you've used Nmap before, the flags should feel immediately familiar.

## Uninstall

```bash
./uninstall.sh
```

## Building from source instead

If you're on a non-x86_64 system, or just want to build it yourself:

```bash
cd source
cargo build --release
sudo ./target/release/nmor -sS 127.0.0.1
```

Requires Rust (https://rustup.rs) — any reasonably recent stable toolchain.

## Platform support

- **Linux (native or WSL2):** fully supported.
- **Windows (native):** not supported yet — raw sockets on Windows need an
  entirely different API (Npcap/WinPcap) than the Linux raw-socket path
  this build uses. Use WSL2 in the meantime.
- **macOS:** untested; likely needs minor portability work even though the
  raw-socket APIs are closer to Linux's than Windows' are.
