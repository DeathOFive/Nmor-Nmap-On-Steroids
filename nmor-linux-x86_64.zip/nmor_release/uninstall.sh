#!/usr/bin/env bash
set -euo pipefail
DEST="/usr/local/bin/nmor"
if [ -f "$DEST" ]; then
    echo "Removing $DEST (you'll be asked for your password)..."
    sudo rm -f "$DEST"
    echo "Done."
else
    echo "nmor isn't installed at $DEST — nothing to do."
fi
