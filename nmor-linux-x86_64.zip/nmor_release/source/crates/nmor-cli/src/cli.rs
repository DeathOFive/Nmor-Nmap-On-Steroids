use clap::Parser;
use std::path::PathBuf;

/// Nmor — Nmap on Roids. A raw-socket SYN scanner written in Rust.
///
/// Flag names deliberately mirror Nmap so existing muscle memory transfers
/// directly. A few flags accepted for compatibility are currently no-ops
/// (noted below) since this version only implements one scan technique.
#[derive(Parser, Debug)]
#[command(name = "nmor", version, about, long_about = None)]
pub struct Cli {
    /// Target(s): IP, hostname, CIDR block, or range, comma-separated
    /// (e.g. "scanme.nmap.org,10.0.0.0/24,192.168.1.1-50")
    pub targets: String,

    /// Scan technique + modifiers, Nmap-style. Letters can be combined in
    /// one flag (-sSV = SYN scan + version detection) or given as separate
    /// occurrences (-sS -sV). Implemented technique letters: S (SYN scan),
    /// T (TCP connect scan), A (ACK scan, firewall mapping). V is the
    /// version-detection modifier (lightweight banner grab), combinable
    /// with any technique. Other Nmap scan-type letters are accepted but
    /// rejected with a clear "not implemented yet" message.
    #[arg(short = 's', value_name = "TYPE", action = clap::ArgAction::Append)]
    pub scan_type: Vec<String>,

    /// OS detection (Nmap: -O). Not implemented yet — accepted so the flag
    /// doesn't error out of habit, but currently a no-op.
    #[arg(short = 'O', default_value_t = false)]
    pub os_detect: bool,

    /// Ports to scan: "22,80,443", "1-1024", "-" (all 65535), "-1024",
    /// "1024-". Defaults to the built-in top-100 most commonly open ports.
    #[arg(short = 'p', long = "ports")]
    pub ports: Option<String>,

    /// Fast mode: scan only the built-in top-100 most common ports.
    /// This is the default behavior already; the flag exists for users
    /// who type it out of Nmap habit.
    #[arg(short = 'F', default_value_t = false)]
    pub fast: bool,

    /// Timing template (0=paranoid .. 5=insane), Nmap-style. Maps to
    /// initial/min/max packet-rate presets. Overridden by explicit
    /// --min-rate/--max-rate if both are given.
    #[arg(short = 'T', value_name = "0-5")]
    pub timing: Option<u8>,

    /// Minimum send rate the adaptive controller will back off to (pps).
    #[arg(long, value_name = "PPS")]
    pub min_rate: Option<u64>,

    /// Maximum send rate the adaptive controller will ramp up to (pps).
    #[arg(long, value_name = "PPS")]
    pub max_rate: Option<u64>,

    /// Skip host discovery (Nmap: -Pn). Nmor never pings before scanning,
    /// so this is always effectively on already — accepted purely for
    /// Nmap-command-line compatibility. Only the literal "-Pn" form is
    /// recognized (matching real Nmap's most common usage); other -P
    /// probe-type suffixes are not implemented.
    #[arg(short = 'P', value_name = "n")]
    pub no_ping: Option<String>,

    /// Never do reverse-DNS resolution on results. Nmor doesn't do that
    /// anyway in this version, so this is a no-op accepted for compatibility.
    #[arg(short = 'n', default_value_t = false)]
    pub no_dns: bool,

    /// Spoof / set the source IP address used for outgoing packets
    /// (Nmap: -S).
    #[arg(short = 'S', long = "source-ip", value_name = "IP")]
    pub src_ip: Option<String>,

    /// Source port used for every probe (Nmap: -g / --source-port).
    #[arg(short = 'g', long = "source-port", value_name = "PORT")]
    pub src_port: Option<u16>,

    /// Network interface to use. Accepted for Nmap compatibility; not
    /// currently used since Nmor sends via a Layer-4 raw socket and lets
    /// the kernel route by destination IP rather than binding an interface.
    #[arg(short = 'e', long = "interface", value_name = "IFACE")]
    pub interface: Option<String>,

    /// Seconds to keep listening for trailing replies after all probes
    /// are sent (Nmor extension, no direct Nmap equivalent).
    #[arg(long, default_value_t = 3)]
    pub grace: u64,

    /// Show the reason a port was classified into its state
    /// (e.g. syn-ack, reset, no-response), Nmap: --reason.
    #[arg(long, default_value_t = false)]
    pub reason: bool,

    /// Write normal (human-readable) output to file (Nmap: -oN).
    #[arg(long = "oN", value_name = "FILE")]
    pub out_normal: Option<PathBuf>,

    /// Write greppable output to file (Nmap: -oG).
    #[arg(long = "oG", value_name = "FILE")]
    pub out_greppable: Option<PathBuf>,

    /// Write JSON output to file. Nmor extension — real Nmap has no native
    /// JSON output (its closest equivalent is XML via -oX, which is also
    /// implemented here).
    #[arg(long = "oJ", value_name = "FILE")]
    pub out_json: Option<PathBuf>,

    /// Write XML output to file (Nmap: -oX).
    #[arg(long = "oX", value_name = "FILE")]
    pub out_xml: Option<PathBuf>,

    /// Write every supported format at once using BASENAME.{txt,gnmap,json,xml}
    /// (Nmap: -oA).
    #[arg(long = "oA", value_name = "BASENAME")]
    pub out_all: Option<PathBuf>,

    /// Per-connection timeout (ms) for banner grabs when -sV is used.
    #[arg(long = "version-timeout", default_value_t = 2000)]
    pub version_timeout_ms: u64,

    /// Per-probe timeout (ms) for TCP connect scan (-sT).
    #[arg(long = "connect-timeout", default_value_t = 800)]
    pub connect_timeout_ms: u64,

    /// Increase verbosity. Repeatable: -v, -vv (Nmap-style).
    #[arg(short = 'v', action = clap::ArgAction::Count)]
    pub verbose: u8,
}
