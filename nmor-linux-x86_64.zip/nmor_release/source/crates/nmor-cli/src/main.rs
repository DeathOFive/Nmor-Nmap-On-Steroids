mod cli;
mod output;
mod resolve;
mod timing;

use clap::Parser;
use cli::Cli;
use colored::Colorize;
use nmor_scanner::{ConnectScanOptions, ScanOptions};
use rand::Rng;
use std::process::ExitCode;
use std::time::Duration;

/// What technique to actually run, decoded from the combined -s flag value(s).
enum Technique {
    Syn,
    Connect,
    Ack,
}

/// Real Nmap accepts "-oN file", "-oG file", "-oJ file", "-oX file",
/// "-oA base" as single-dash multi-letter flags — a parsing style clap's
/// derive macro doesn't support natively (it expects "--oN"). Rather than
/// break compatibility with the Nmap syntax users type most often, we
/// rewrite the single-dash form to the double-dash form clap understands
/// before parsing. The attached-value patterns (-sS, -T4, -Pn) clap
/// already handles natively as single-character short flags with an
/// attached value, so those need no rewriting.
fn preprocess_args(args: std::env::Args) -> Vec<String> {
    const REWRITE: [&str; 5] = ["-oN", "-oG", "-oJ", "-oX", "-oA"];
    let raw: Vec<String> = args.collect();
    let mut out: Vec<String> = Vec::with_capacity(raw.len());
    let mut i = 0;
    while i < raw.len() {
        let a = &raw[i];

        if REWRITE.contains(&a.as_str()) {
            out.push(format!("-{a}"));
            i += 1;
            continue;
        }

        // "-p -1024" / "-p 1024-" / "-p -" (space-separated open-ended port
        // spec) would otherwise look like "-p" followed by a stray flag to
        // clap, since the next token starts with '-'. Real Nmap accepts
        // this with or without the space; merge it into "-p<spec>" so both
        // forms work here too.
        if a == "-p" && i + 1 < raw.len() {
            let next = &raw[i + 1];
            let looks_like_port_spec = next == "-"
                || (next.starts_with('-') && next[1..].chars().all(|c| c.is_ascii_digit() || c == ','));
            if looks_like_port_spec {
                out.push(format!("-p{next}"));
                i += 2;
                continue;
            }
        }

        out.push(a.clone());
        i += 1;
    }
    out
}

/// Decode the combined -s flag value(s) (e.g. ["SV"] or ["S","V"]) into a
/// scan technique plus whether version detection (-V) was requested.
/// Returns Err with a user-facing message for unimplemented/unknown letters.
fn decode_scan_flags(scan_type: &[String]) -> Result<(Technique, bool), String> {
    let combined: String = scan_type.join("");
    if combined.is_empty() {
        return Ok((Technique::Syn, false));
    }
    if combined.eq_ignore_ascii_case("n") {
        return Err("-sn (ping scan / host discovery only) is not implemented yet".to_string());
    }

    let mut technique: Option<char> = None;
    let mut version_detection = false;

    for ch in combined.chars() {
        match ch {
            'S' | 'T' | 'A' => {
                if let Some(existing) = technique {
                    if existing != ch {
                        return Err(format!(
                            "can't combine scan techniques -s{existing} and -s{ch} in one run"
                        ));
                    }
                } else {
                    technique = Some(ch);
                }
            }
            'V' => version_detection = true,
            other @ ('U' | 'W' | 'N' | 'F' | 'X' | 'M' | 'O' | 'Y' | 'Z' | 'I' | 'R' | 'C') => {
                return Err(format!(
                    "-s{other} is not implemented yet — implemented techniques are -sS (SYN), -sT (connect), -sA (ACK)"
                ));
            }
            other => return Err(format!("-s{other} is not a recognized scan flag")),
        }
    }

    let technique = match technique {
        Some('S') | None => Technique::Syn,
        Some('T') => Technique::Connect,
        Some('A') => Technique::Ack,
        _ => unreachable!(),
    };
    Ok((technique, version_detection))
}

fn main() -> ExitCode {
    let cli = Cli::parse_from(preprocess_args(std::env::args()));

    let (technique, version_detection) = match decode_scan_flags(&cli.scan_type) {
        Ok(t) => t,
        Err(msg) => {
            eprintln!("{} {}", "error:".red(), msg);
            return ExitCode::FAILURE;
        }
    };

    // Raw-socket techniques (SYN, ACK) need root. Connect scan doesn't.
    let needs_root = matches!(technique, Technique::Syn | Technique::Ack);
    if needs_root && !nmor_net::has_raw_socket_privilege() {
        eprintln!(
            "{}",
            "nmor requires root privileges to send raw packets for this scan technique.".red().bold()
        );
        eprintln!("Try running again with: sudo nmor ...");
        eprintln!("(Tip: -sT, the TCP connect scan, doesn't require root.)");
        return ExitCode::FAILURE;
    }

    if cli.os_detect {
        eprintln!(
            "{} -O (OS detection) is not implemented yet — planned as a minimal TTL/window heuristic, not full fingerprinting.",
            "note:".yellow()
        );
    }

    // --- Targets: IP / CIDR / range / hostname (DNS-resolved) ---
    let targets_v4 = match resolve::resolve_targets(&cli.targets) {
        Ok(t) => t,
        Err(e) => {
            eprintln!("{} {}", "error resolving targets:".red(), e);
            return ExitCode::FAILURE;
        }
    };
    if targets_v4.is_empty() {
        eprintln!("{}", "error: no valid IPv4 targets to scan".red());
        return ExitCode::FAILURE;
    }

    // --- Ports ---
    let ports: Vec<u16> = match &cli.ports {
        Some(spec) => match nmor_core::parse_ports(spec) {
            Ok(p) => p,
            Err(e) => {
                eprintln!("{} {}", "error parsing ports:".red(), e);
                return ExitCode::FAILURE;
            }
        },
        None => nmor_core::TOP_100_PORTS.to_vec(),
    };
    let _ = cli.fast; // top-100 is already our default when -p isn't given

    // --- Source IP override (-S) ---
    let src_ip = match &cli.src_ip {
        Some(s) => match s.parse::<std::net::Ipv4Addr>() {
            Ok(ip) => Some(ip),
            Err(_) => {
                eprintln!("{} '{}' is not a valid IPv4 address", "error:".red(), s);
                return ExitCode::FAILURE;
            }
        },
        None => None,
    };

    let src_port = cli.src_port.unwrap_or_else(|| rand::thread_rng().gen_range(20000..60000));

    // --- Rate: -T<n> template, overridden by explicit --min-rate/--max-rate ---
    let mut initial_pps = 100u64;
    let mut min_pps = 10u64;
    let mut max_pps = 50_000u64;

    if let Some(t) = cli.timing {
        match timing::preset_for_template(t) {
            Ok(p) => {
                initial_pps = p.initial_pps;
                min_pps = p.min_pps;
                max_pps = p.max_pps;
            }
            Err(e) => {
                eprintln!("{} {}", "error:".red(), e);
                return ExitCode::FAILURE;
            }
        }
    }
    if let Some(mr) = cli.min_rate {
        min_pps = mr;
        initial_pps = initial_pps.max(mr);
    }
    if let Some(mx) = cli.max_rate {
        max_pps = mx;
        initial_pps = initial_pps.min(mx);
        min_pps = min_pps.min(mx);
    }

    if let Some(v) = &cli.no_ping {
        if v != "n" {
            eprintln!(
                "{} -P{} isn't recognized; only -Pn (skip host discovery) is accepted, and it's a no-op since nmor never pings anyway.",
                "warning:".yellow(),
                v
            );
        }
    }
    if cli.verbose > 0 && cli.interface.is_some() {
        eprintln!(
            "{} -e/--interface is accepted for compatibility but not used yet — nmor sends via a Layer-4 raw socket and lets the kernel route by destination IP.",
            "note:".yellow()
        );
    }

    let technique_label = match technique {
        Technique::Syn => "SYN scan (-sS)",
        Technique::Connect => "TCP connect scan (-sT)",
        Technique::Ack => "ACK scan (-sA)",
    };
    println!(
        "{} {} — {} target(s), {} port(s) each ({} total probes)",
        "Starting Nmor:".bold(),
        technique_label,
        targets_v4.len(),
        ports.len(),
        targets_v4.len() * ports.len()
    );

    let mut report = match technique {
        Technique::Syn => {
            let opts = ScanOptions {
                src_port,
                src_ip,
                initial_pps,
                min_pps,
                max_pps,
                grace_period: Duration::from_secs(cli.grace),
                ..Default::default()
            };
            match nmor_scanner::run_syn_scan(&targets_v4, &ports, &opts) {
                Ok(r) => r,
                Err(e) => {
                    eprintln!("{} {}", "scan failed:".red(), e);
                    return ExitCode::FAILURE;
                }
            }
        }
        Technique::Ack => {
            let opts = ScanOptions {
                src_port,
                src_ip,
                initial_pps,
                min_pps,
                max_pps,
                grace_period: Duration::from_secs(cli.grace),
                ..Default::default()
            };
            match nmor_scanner::run_ack_scan(&targets_v4, &ports, &opts) {
                Ok(r) => r,
                Err(e) => {
                    eprintln!("{} {}", "scan failed:".red(), e);
                    return ExitCode::FAILURE;
                }
            }
        }
        Technique::Connect => {
            let opts = ConnectScanOptions {
                timeout: Duration::from_millis(cli.connect_timeout_ms),
                ..Default::default()
            };
            nmor_scanner::run_connect_scan(&targets_v4, &ports, &opts)
        }
    };

    if version_detection {
        if cli.verbose > 0 {
            println!("{}", "Grabbing service banners (-sV)...".bold());
        }
        nmor_scanner::grab_banners(&mut report.hosts, Duration::from_millis(cli.version_timeout_ms));
    }

    let verbose = cli.verbose > 0;
    output::print_pretty(&report, verbose, cli.reason);

    if let Some(path) = &cli.out_normal {
        if let Err(e) = output::write_to_file(path, &output::format_normal(&report, cli.reason)) {
            eprintln!("{} failed to write -oN file: {}", "warning:".yellow(), e);
        }
    }
    if let Some(path) = &cli.out_greppable {
        if let Err(e) = output::write_to_file(path, &output::format_greppable(&report)) {
            eprintln!("{} failed to write -oG file: {}", "warning:".yellow(), e);
        }
    }
    if let Some(path) = &cli.out_json {
        match output::format_json(&report) {
            Ok(json) => {
                if let Err(e) = output::write_to_file(path, &json) {
                    eprintln!("{} failed to write -oJ file: {}", "warning:".yellow(), e);
                }
            }
            Err(e) => eprintln!("{} failed to serialize JSON: {}", "warning:".yellow(), e),
        }
    }
    if let Some(path) = &cli.out_xml {
        if let Err(e) = output::write_to_file(path, &output::format_xml(&report, cli.reason)) {
            eprintln!("{} failed to write -oX file: {}", "warning:".yellow(), e);
        }
    }
    if let Some(base) = &cli.out_all {
        let base_str = base.to_string_lossy().to_string();
        let normal_path = std::path::PathBuf::from(format!("{base_str}.txt"));
        let grep_path = std::path::PathBuf::from(format!("{base_str}.gnmap"));
        let json_path = std::path::PathBuf::from(format!("{base_str}.json"));
        let xml_path = std::path::PathBuf::from(format!("{base_str}.xml"));

        if let Err(e) = output::write_to_file(&normal_path, &output::format_normal(&report, cli.reason)) {
            eprintln!("{} failed to write -oA normal file: {}", "warning:".yellow(), e);
        }
        if let Err(e) = output::write_to_file(&grep_path, &output::format_greppable(&report)) {
            eprintln!("{} failed to write -oA greppable file: {}", "warning:".yellow(), e);
        }
        if let Err(e) = output::write_to_file(&xml_path, &output::format_xml(&report, cli.reason)) {
            eprintln!("{} failed to write -oA xml file: {}", "warning:".yellow(), e);
        }
        match output::format_json(&report) {
            Ok(json) => {
                if let Err(e) = output::write_to_file(&json_path, &json) {
                    eprintln!("{} failed to write -oA json file: {}", "warning:".yellow(), e);
                }
            }
            Err(e) => eprintln!("{} failed to serialize JSON for -oA: {}", "warning:".yellow(), e),
        }
    }

    ExitCode::SUCCESS
}
