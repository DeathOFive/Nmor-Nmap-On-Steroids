use colored::Colorize;
use nmor_core::{PortState, ScanReport};
use std::fmt::Write as _;
use std::fs;
use std::io;
use std::path::Path;

fn state_label_colored(state: PortState) -> colored::ColoredString {
    match state {
        PortState::Open => "open".green().bold(),
        PortState::Closed => "closed".red(),
        PortState::Filtered => "filtered".yellow(),
        PortState::OpenFiltered => "open|filtered".yellow(),
        PortState::Unfiltered => "unfiltered".cyan(),
    }
}

/// The "reason" Nmap shows with --reason: which packet (or absence of one)
/// led to this classification.
fn reason_label(state: PortState) -> &'static str {
    match state {
        PortState::Open => "syn-ack",
        PortState::Closed => "reset",
        PortState::Filtered | PortState::OpenFiltered => "no-response",
        PortState::Unfiltered => "reset",
    }
}

/// Pretty, colorized terminal output. If `verbose` is false, only the
/// "interesting" states (Open, Unfiltered) are listed per host
/// (closed/filtered ports are summarized as a count instead, matching
/// Nmap's default "don't drown you in noise" UX).
pub fn print_pretty(report: &ScanReport, verbose: bool, reason: bool) {
    for host in &report.hosts {
        println!("\n{} {}", "Nmor scan report for".bold(), host.ip.to_string().cyan().bold());

        let interesting: Vec<_> = host
            .ports
            .iter()
            .filter(|p| matches!(p.state, PortState::Open | PortState::Unfiltered))
            .collect();
        let closed_count = host.ports.iter().filter(|p| p.state == PortState::Closed).count();
        let filtered_count = host
            .ports
            .iter()
            .filter(|p| matches!(p.state, PortState::Filtered | PortState::OpenFiltered))
            .count();

        let header = if reason {
            format!("{:<10} {:<14} REASON", "PORT", "STATE")
        } else {
            format!("{:<10} STATE", "PORT")
        };

        let print_row = |pr: &nmor_core::PortResult| {
            let banner_suffix = pr.banner.as_ref().map(|b| format!("  ({b})")).unwrap_or_default();
            if reason {
                println!(
                    "{:<10} {:<14} {}{}",
                    format!("{}/tcp", pr.port),
                    state_label_colored(pr.state),
                    reason_label(pr.state),
                    banner_suffix
                );
            } else {
                println!("{:<10} {}{}", format!("{}/tcp", pr.port), state_label_colored(pr.state), banner_suffix);
            }
        };

        if verbose {
            println!("{header}");
            for pr in &host.ports {
                print_row(pr);
            }
        } else {
            if interesting.is_empty() {
                println!("  no open ports found");
            } else {
                println!("{header}");
                for pr in &interesting {
                    print_row(pr);
                }
            }
            if closed_count > 0 || filtered_count > 0 {
                println!(
                    "  ({closed_count} closed, {filtered_count} filtered port(s) not shown — use -v to see all)"
                );
            }
        }
    }

    println!(
        "\n{} {} host(s) scanned in {:.2}s — {} probes sent, {} replies received",
        "Nmor done:".bold(),
        report.hosts.len(),
        report.total_duration.as_secs_f64(),
        report.packets_sent,
        report.packets_received,
    );
}

/// Plain-text version of the pretty output (no ANSI color codes), for -oN.
pub fn format_normal(report: &ScanReport, reason: bool) -> String {
    let mut out = String::new();
    for host in &report.hosts {
        let _ = writeln!(out, "\nNmor scan report for {}", host.ip);
        if reason {
            let _ = writeln!(out, "{:<10} {:<14} REASON", "PORT", "STATE");
            for pr in &host.ports {
                let _ = writeln!(
                    out,
                    "{:<10} {:<14} {}{}",
                    format!("{}/tcp", pr.port),
                    pr.state.to_string(),
                    reason_label(pr.state),
                    pr.banner.as_ref().map(|b| format!("  ({b})")).unwrap_or_default()
                );
            }
        } else {
            let _ = writeln!(out, "{:<10} STATE", "PORT");
            for pr in &host.ports {
                let _ = writeln!(
                    out,
                    "{:<10} {}{}",
                    format!("{}/tcp", pr.port),
                    pr.state,
                    pr.banner.as_ref().map(|b| format!("  ({b})")).unwrap_or_default()
                );
            }
        }
    }
    let _ = writeln!(
        out,
        "\nNmor done: {} host(s) scanned in {:.2}s — {} probes sent, {} replies received",
        report.hosts.len(),
        report.total_duration.as_secs_f64(),
        report.packets_sent,
        report.packets_received,
    );
    out
}

/// Nmap -oG style: one line per host, ports comma-separated as port/state/tcp.
pub fn format_greppable(report: &ScanReport) -> String {
    let mut out = String::new();
    for host in &report.hosts {
        let ports_str = host
            .ports
            .iter()
            .map(|p| format!("{}/{}/tcp", p.port, p.state))
            .collect::<Vec<_>>()
            .join(", ");
        let _ = writeln!(out, "Host: {}\tPorts: {}", host.ip, ports_str);
    }
    out
}

pub fn format_json(report: &ScanReport) -> serde_json::Result<String> {
    serde_json::to_string_pretty(report)
}

fn xml_escape(s: &str) -> String {
    s.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
        .replace('\'', "&apos;")
}

/// Nmap-compatible-ish XML output (-oX). Not byte-identical to real Nmap's
/// schema (no DTD, no script/OS-detection elements), but follows the same
/// element structure for the parts we do have (nmaprun/host/address/ports/
/// port/state/service), so existing Nmap-XML tooling has a reasonable shot
/// at reading it.
pub fn format_xml(report: &ScanReport, reason: bool) -> String {
    let mut out = String::new();
    let _ = writeln!(out, r#"<?xml version="1.0" encoding="UTF-8"?>"#);
    let _ = writeln!(
        out,
        r#"<nmaprun scanner="nmor" version="{}" elapsed="{:.2}">"#,
        env!("CARGO_PKG_VERSION"),
        report.total_duration.as_secs_f64()
    );

    for host in &report.hosts {
        let _ = writeln!(out, "  <host>");
        let _ = writeln!(out, r#"    <status state="up"/>"#);
        let addrtype = if host.ip.is_ipv4() { "ipv4" } else { "ipv6" };
        let _ = writeln!(
            out,
            r#"    <address addr="{}" addrtype="{}"/>"#,
            xml_escape(&host.ip.to_string()),
            addrtype
        );
        let _ = writeln!(out, "    <ports>");
        for pr in &host.ports {
            let _ = writeln!(out, r#"      <port protocol="tcp" portid="{}">"#, pr.port);
            if reason {
                let _ = writeln!(
                    out,
                    r#"        <state state="{}" reason="{}"/>"#,
                    pr.state,
                    reason_label(pr.state)
                );
            } else {
                let _ = writeln!(out, r#"        <state state="{}"/>"#, pr.state);
            }
            if let Some(banner) = &pr.banner {
                let _ = writeln!(out, r#"        <service banner="{}"/>"#, xml_escape(banner));
            }
            let _ = writeln!(out, "      </port>");
        }
        let _ = writeln!(out, "    </ports>");
        let _ = writeln!(out, "  </host>");
    }

    let total_interesting: usize = report
        .hosts
        .iter()
        .map(|h| {
            h.ports
                .iter()
                .filter(|p| matches!(p.state, PortState::Open | PortState::Unfiltered))
                .count()
        })
        .sum();
    let _ = writeln!(
        out,
        r#"  <runstats><finished elapsed="{:.2}" summary="{} host(s) scanned, {} interesting port(s) found"/><hosts up="{}" down="0" total="{}"/></runstats>"#,
        report.total_duration.as_secs_f64(),
        report.hosts.len(),
        total_interesting,
        report.hosts.len(),
        report.hosts.len(),
    );
    let _ = writeln!(out, "</nmaprun>");
    out
}

pub fn write_to_file(path: &Path, contents: &str) -> io::Result<()> {
    fs::write(path, contents)
}
