//! Nmap's -T0..-T5 timing templates, approximated as rate presets for our
//! adaptive controller. Real Nmap's timing templates also tune parallelism,
//! per-probe delay, and timeout/retry counts — concepts that don't map
//! 1:1 onto a stateless cookie-based scanner. We translate the *spirit*
//! of each template (how aggressive/stealthy to be) into pps bounds.

pub struct RatePreset {
    pub initial_pps: u64,
    pub min_pps: u64,
    pub max_pps: u64,
}

pub fn preset_for_template(t: u8) -> Result<RatePreset, String> {
    let preset = match t {
        0 => RatePreset { initial_pps: 1, min_pps: 1, max_pps: 2 }, // paranoid
        1 => RatePreset { initial_pps: 2, min_pps: 1, max_pps: 5 }, // sneaky
        2 => RatePreset { initial_pps: 10, min_pps: 5, max_pps: 50 }, // polite
        3 => RatePreset { initial_pps: 100, min_pps: 10, max_pps: 50_000 }, // normal (default)
        4 => RatePreset { initial_pps: 1_000, min_pps: 100, max_pps: 100_000 }, // aggressive
        5 => RatePreset { initial_pps: 5_000, min_pps: 500, max_pps: 200_000 }, // insane
        other => return Err(format!("-T{other} is invalid; timing templates range from -T0 to -T5")),
    };
    Ok(preset)
}
