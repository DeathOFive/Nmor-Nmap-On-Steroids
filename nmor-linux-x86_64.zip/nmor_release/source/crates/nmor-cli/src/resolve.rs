//! Turns a raw target spec (comma-separated IPs/CIDR/ranges/hostnames) into
//! a flat Vec<Ipv4Addr>, resolving any hostnames via DNS — matching Nmap's
//! behavior of accepting "scanme.nmap.org" directly on the command line.

use std::net::{Ipv4Addr, ToSocketAddrs};

#[derive(Debug, thiserror::Error)]
pub enum ResolveError {
    #[error("'{0}' could not be parsed as an IP/CIDR/range and failed to resolve as a hostname")]
    Unresolvable(String),
    #[error("hostname '{0}' resolved, but only to IPv6 addresses (not supported yet)")]
    OnlyIpv6(String),
}

/// Resolve a single token: try IP/CIDR/range parsing first (cheap, no I/O),
/// then fall back to a DNS lookup if that fails.
fn resolve_token(token: &str) -> Result<Vec<Ipv4Addr>, ResolveError> {
    if let Ok(ips) = nmor_core::parse_targets(token) {
        return Ok(ips
            .into_iter()
            .filter_map(|ip| match ip {
                std::net::IpAddr::V4(v4) => Some(v4),
                std::net::IpAddr::V6(_) => None,
            })
            .collect());
    }

    // Fall back to DNS. ToSocketAddrs needs a port even though we discard it.
    let lookup = format!("{token}:0");
    match lookup.to_socket_addrs() {
        Ok(addrs) => {
            let v4s: Vec<Ipv4Addr> = addrs
                .filter_map(|a| match a.ip() {
                    std::net::IpAddr::V4(v4) => Some(v4),
                    std::net::IpAddr::V6(_) => None,
                })
                .collect();
            if v4s.is_empty() {
                Err(ResolveError::OnlyIpv6(token.to_string()))
            } else {
                Ok(v4s)
            }
        }
        Err(_) => Err(ResolveError::Unresolvable(token.to_string())),
    }
}

/// Resolve a full comma-separated target spec into a flat, deduplicated
/// list of IPv4 addresses.
pub fn resolve_targets(spec: &str) -> Result<Vec<Ipv4Addr>, ResolveError> {
    let mut out = Vec::new();
    for token in spec.split(',') {
        let token = token.trim();
        if token.is_empty() {
            continue;
        }
        out.extend(resolve_token(token)?);
    }
    out.sort_unstable();
    out.dedup();
    Ok(out)
}
