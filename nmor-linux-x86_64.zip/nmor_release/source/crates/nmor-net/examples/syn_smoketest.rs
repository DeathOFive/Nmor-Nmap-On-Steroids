use nmor_net::{has_raw_socket_privilege, initial_seq, open_raw_channel, random_secret, validate_reply};
use std::net::{Ipv4Addr, TcpListener};
use std::time::Duration;

fn main() {
    println!("root privilege check: {}", has_raw_socket_privilege());

    // Stand up a real listener on loopback so we have something to SYN at.
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind failed");
    let dst_port = listener.local_addr().unwrap().port();
    println!("listening on 127.0.0.1:{dst_port}");

    let dst_ip = Ipv4Addr::new(127, 0, 0, 1);
    let src_ip = Ipv4Addr::new(127, 0, 0, 1);
    let src_port: u16 = 44321;

    let secret = random_secret();
    let seq = initial_seq(secret, src_port, dst_ip, dst_port);

    let (mut sender, mut receiver) = open_raw_channel().expect("failed to open raw channel");

    println!("sending SYN -> {dst_ip}:{dst_port} from src_port={src_port} seq={seq:#x}");
    sender.send_syn(src_ip, dst_ip, src_port, dst_port, seq)
        .expect("send_syn failed");

    let mut found = false;
    for _ in 0..50 {
        if let Some(reply) = receiver.recv_one(Duration::from_millis(200)) {
            println!(
                "reply: {}:{} -> dst_port={} flags={:#04x} ack={:#x}",
                reply.src_ip, reply.src_port, reply.dst_port, reply.flags, reply.ack
            );
            if reply.dst_port == src_port {
                let valid = validate_reply(secret, src_port, reply.src_ip, reply.src_port, reply.ack);
                println!("  -> relevant reply, cookie valid = {valid}");
                if valid {
                    found = true;
                    break;
                }
            }
        }
    }

    if found {
        println!("SUCCESS: observed a cookie-validated reply to our raw SYN");
    } else {
        println!("FAILURE: no validated reply observed");
        std::process::exit(1);
    }

    // --- Now test against a CLOSED port (nothing listening) ---
    drop(listener);
    let closed_port: u16 = 54999; // assume nothing's listening here
    let src_port2: u16 = 44322;
    let seq2 = initial_seq(secret, src_port2, dst_ip, closed_port);
    println!("\nsending SYN -> {dst_ip}:{closed_port} (expecting RST, port should be closed)");
    sender.send_syn(src_ip, dst_ip, src_port2, closed_port, seq2)
        .expect("send_syn failed");

    let mut closed_found = false;
    for _ in 0..50 {
        if let Some(reply) = receiver.recv_one(Duration::from_millis(200)) {
            if reply.dst_port == src_port2 {
                let valid = validate_reply(secret, src_port2, reply.src_ip, reply.src_port, reply.ack);
                println!(
                    "  closed-port reply: flags={:#04x} ack={:#x} valid={}",
                    reply.flags, reply.ack, valid
                );
                if valid {
                    // RST flag is 0x04; RST+ACK is 0x14
                    closed_found = reply.flags & 0x04 != 0;
                    break;
                }
            }
        }
    }
    println!(
        "closed-port RST observed: {}",
        if closed_found { "YES" } else { "NO (maybe filtered by sandbox)" }
    );
}
