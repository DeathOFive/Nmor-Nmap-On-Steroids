//! Raw socket channel for sending SYN segments and receiving TCP replies.
//! Requires root / CAP_NET_RAW on Linux, since this opens an IPPROTO_TCP
//! raw socket (SOCK_RAW), bypassing the kernel's normal TCP state machine.

use crate::packet::{build_ack_segment, build_syn_segment};
use pnet::packet::ip::IpNextHeaderProtocols;
use pnet::packet::tcp::TcpPacket;
use pnet::transport::{
    tcp_packet_iter, transport_channel, TransportChannelType, TransportProtocol, TransportReceiver,
    TransportSender,
};
use std::io;
use std::net::{IpAddr, Ipv4Addr};
use std::time::Duration;
use thiserror::Error;

#[derive(Debug, Error)]
pub enum ChannelError {
    #[error("failed to open raw socket: {0} (are you running as root / with CAP_NET_RAW?)")]
    OpenFailed(io::Error),
    #[error("failed to send packet: {0}")]
    SendFailed(io::Error),
}

/// A single observed TCP reply relevant to our scan.
#[derive(Debug, Clone, Copy)]
pub struct TcpReply {
    pub src_ip: Ipv4Addr,
    pub src_port: u16,
    pub dst_port: u16,
    pub flags: u8,
    pub seq: u32,
    pub ack: u32,
}

/// Returns true if the process can actually open a raw socket — either
/// because it's running as root, or because the binary has been granted
/// CAP_NET_RAW via `setcap` (e.g. `sudo setcap cap_net_raw+ep /path/to/nmor`),
/// which lets non-root users run scans without `sudo` every time.
///
/// We deliberately test by attempting the real syscall rather than just
/// checking `geteuid() == 0`, since EUID alone misses the capability case
/// entirely — a setcap'd binary run by a normal user has EUID != 0 but the
/// raw socket open succeeds anyway. Linux-only check (matches our current
/// platform scope).
pub fn has_raw_socket_privilege() -> bool {
    unsafe {
        let fd = libc::socket(libc::AF_INET, libc::SOCK_RAW, libc::IPPROTO_TCP);
        if fd >= 0 {
            libc::close(fd);
            true
        } else {
            false
        }
    }
}

pub struct RawSender {
    tx: TransportSender,
}

pub struct RawReceiver {
    rx: TransportReceiver,
}

/// Open a raw TCP socket and split it into independently-ownable sender and
/// receiver halves, so a sender thread and a receiver thread can each own
/// one without fighting over a shared lock.
pub fn open_raw_channel() -> Result<(RawSender, RawReceiver), ChannelError> {
    let protocol = TransportChannelType::Layer4(TransportProtocol::Ipv4(IpNextHeaderProtocols::Tcp));
    let (tx, rx) = transport_channel(1 << 16, protocol).map_err(ChannelError::OpenFailed)?;
    Ok((RawSender { tx }, RawReceiver { rx }))
}

impl RawSender {
    /// Craft and send a single SYN to dst_ip:dst_port from src_port, using
    /// the given stateless sequence number (see cookie.rs).
    pub fn send_syn(
        &mut self,
        src_ip: Ipv4Addr,
        dst_ip: Ipv4Addr,
        src_port: u16,
        dst_port: u16,
        seq: u32,
    ) -> Result<(), ChannelError> {
        let segment = build_syn_segment(src_ip, dst_ip, src_port, dst_port, seq);
        self.send_raw(&segment, dst_ip)
    }

    /// Craft and send a single bare ACK to dst_ip:dst_port from src_port,
    /// for ACK-scan firewall mapping (see cookie::validate_ack_scan_reply).
    pub fn send_ack(
        &mut self,
        src_ip: Ipv4Addr,
        dst_ip: Ipv4Addr,
        src_port: u16,
        dst_port: u16,
        ack_value: u32,
    ) -> Result<(), ChannelError> {
        let segment = build_ack_segment(src_ip, dst_ip, src_port, dst_port, ack_value);
        self.send_raw(&segment, dst_ip)
    }

    fn send_raw(&mut self, segment: &[u8], dst_ip: Ipv4Addr) -> Result<(), ChannelError> {
        let packet = TcpPacket::new(segment).expect("fixed-size buffer is valid TCP packet");
        self.tx
            .send_to(packet, IpAddr::V4(dst_ip))
            .map_err(ChannelError::SendFailed)?;
        Ok(())
    }
}

impl RawReceiver {
    /// Block (up to `timeout`) waiting for the next inbound TCP segment and
    /// return it as a TcpReply. Returns None on timeout with no packet.
    /// This does NOT filter for relevance — caller validates via cookie.rs.
    pub fn recv_one(&mut self, timeout: Duration) -> Option<TcpReply> {
        let mut iter = tcp_packet_iter(&mut self.rx);
        match iter.next_with_timeout(timeout) {
            Ok(Some((pkt, addr))) => {
                let src_ip = match addr {
                    IpAddr::V4(v4) => v4,
                    IpAddr::V6(_) => return None, // IPv6 out of scope for now
                };
                Some(TcpReply {
                    src_ip,
                    src_port: pkt.get_source(),
                    dst_port: pkt.get_destination(),
                    flags: pkt.get_flags(),
                    seq: pkt.get_sequence(),
                    ack: pkt.get_acknowledgement(),
                })
            }
            _ => None,
        }
    }
}
