//! Stateless sequence number encoding ("SYN cookie" technique), the same
//! trick zmap/masscan use to scan at high packet rates without keeping a
//! per-probe state table in memory.
//!
//! We encode a keyed hash of (our source port, target ip, target port) into
//! the initial sequence number of the SYN we send. When a reply comes back,
//! we recompute the same hash from the reply's (src ip, src port, dst port)
//! and check that the reply's acknowledgement number equals our encoded
//! sequence number + 1. If it matches, the reply is provably ours — no
//! lookup table required, and an attacker/random noise can't spoof a
//! plausible-looking reply without knowing our per-run secret.

use std::net::Ipv4Addr;

/// Per-run random secret. Regenerate this once at scan start (not per-packet).
pub type Secret = u64;

pub fn random_secret() -> Secret {
    rand::random()
}

/// A small, fast, non-cryptographic keyed mix. We don't need cryptographic
/// security here (this isn't protecting anything sensitive) — just enough
/// avalanche behavior that nearby inputs don't produce nearby outputs, so
/// off-path noise can't easily guess a valid sequence number.
fn mix(secret: Secret, a: u64, b: u64, c: u64) -> u64 {
    let mut x = secret ^ 0x9E3779B97F4A7C15;
    x = x.wrapping_add(a).wrapping_mul(0xBF58476D1CE4E5B9);
    x ^= x >> 31;
    x = x.wrapping_add(b).wrapping_mul(0x94D049BB133111EB);
    x ^= x >> 29;
    x = x.wrapping_add(c).wrapping_mul(0xBF58476D1CE4E5B9);
    x ^= x >> 32;
    x
}

/// Compute the initial sequence number we should send in a SYN to
/// (dst_ip, dst_port) from our chosen src_port.
pub fn initial_seq(secret: Secret, src_port: u16, dst_ip: Ipv4Addr, dst_port: u16) -> u32 {
    let ip_bits = u32::from(dst_ip) as u64;
    let ports = ((src_port as u64) << 16) | dst_port as u64;
    mix(secret, ip_bits, ports, 0) as u32
}

/// Validate that an inbound reply's ack number proves it's a response to a
/// SYN we actually sent (rather than noise, a spoofed packet, or a stray
/// retransmission from an unrelated connection).
///
/// `reply_src_ip` / `reply_src_port` = the host:port that replied to us
/// `our_src_port` = the local port we used to send the original SYN
pub fn validate_reply(
    secret: Secret,
    our_src_port: u16,
    reply_src_ip: Ipv4Addr,
    reply_src_port: u16,
    reply_ack_number: u32,
) -> bool {
    let expected = initial_seq(secret, our_src_port, reply_src_ip, reply_src_port);
    reply_ack_number == expected.wrapping_add(1)
}

/// Validate a reply to an ACK-scan probe. Per RFC 793, a host that gets an
/// ACK not belonging to any real connection responds with a RST whose
/// sequence number equals the ACK field we sent — so (unlike the SYN-scan
/// case) there's no "+1" offset here; we're checking the reply's sequence
/// number directly against the cookie value we put in our outgoing ACK
/// field.
pub fn validate_ack_scan_reply(
    secret: Secret,
    our_src_port: u16,
    reply_src_ip: Ipv4Addr,
    reply_src_port: u16,
    reply_seq_number: u32,
) -> bool {
    let expected = initial_seq(secret, our_src_port, reply_src_ip, reply_src_port);
    reply_seq_number == expected
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roundtrip_validates() {
        let secret = 0xDEADBEEFCAFEu64;
        let src_port = 54321u16;
        let dst_ip = Ipv4Addr::new(10, 0, 0, 5);
        let dst_port = 443u16;

        let seq = initial_seq(secret, src_port, dst_ip, dst_port);

        // Reply comes FROM dst_ip:dst_port back TO our src_port, acking seq+1
        assert!(validate_reply(
            secret,
            src_port,
            dst_ip,
            dst_port,
            seq.wrapping_add(1)
        ));
    }

    #[test]
    fn wrong_ack_rejected() {
        let secret = 42u64;
        let src_port = 1111u16;
        let dst_ip = Ipv4Addr::new(192, 168, 1, 1);
        let dst_port = 80u16;

        let seq = initial_seq(secret, src_port, dst_ip, dst_port);
        assert!(!validate_reply(secret, src_port, dst_ip, dst_port, seq));
        assert!(!validate_reply(
            secret,
            src_port,
            dst_ip,
            dst_port,
            seq.wrapping_add(2)
        ));
    }

    #[test]
    fn different_secret_rejected() {
        let src_port = 2222u16;
        let dst_ip = Ipv4Addr::new(8, 8, 8, 8);
        let dst_port = 53u16;

        let seq = initial_seq(1, src_port, dst_ip, dst_port);
        // Someone else's run (different secret) shouldn't validate against ours
        assert!(!validate_reply(2, src_port, dst_ip, dst_port, seq.wrapping_add(1)));
    }

    #[test]
    fn different_ports_give_different_sequences() {
        let secret = 7u64;
        let dst_ip = Ipv4Addr::new(1, 1, 1, 1);
        let a = initial_seq(secret, 1000, dst_ip, 80);
        let b = initial_seq(secret, 1000, dst_ip, 443);
        assert_ne!(a, b);
    }

    #[test]
    fn ack_scan_roundtrip_validates() {
        let secret = 99u64;
        let src_port = 5000u16;
        let dst_ip = Ipv4Addr::new(172, 16, 0, 1);
        let dst_port = 22u16;

        let cookie = initial_seq(secret, src_port, dst_ip, dst_port);
        // RST's sequence number mirrors the ACK value we sent, no +1.
        assert!(validate_ack_scan_reply(secret, src_port, dst_ip, dst_port, cookie));
        assert!(!validate_ack_scan_reply(
            secret,
            src_port,
            dst_ip,
            dst_port,
            cookie.wrapping_add(1)
        ));
    }
}
