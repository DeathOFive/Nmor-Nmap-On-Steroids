//! Raw TCP SYN packet construction via pnet.

use pnet::packet::tcp::{ipv4_checksum, MutableTcpPacket, TcpFlags, TcpOption};
use std::net::Ipv4Addr;

/// We send a minimal SYN with an MSS option, mirroring a realistic OS
/// stack's default SYN rather than a bare/anomalous header (which some
/// IDS/firewalls treat differently). 20 bytes base header + 4 bytes MSS
/// option (kept 4-byte aligned, no padding needed).
const TCP_HEADER_LEN: usize = 24;

/// Build a raw TCP SYN segment ready to hand to a Layer4 raw socket send.
/// The kernel fills in the IP header for us (we're not using IP_HDRINCL),
/// but the TCP checksum is computed over a pseudo-header that includes the
/// IPs, so we still need to know src/dst IP at packet-build time.
pub fn build_syn_segment(
    src_ip: Ipv4Addr,
    dst_ip: Ipv4Addr,
    src_port: u16,
    dst_port: u16,
    seq: u32,
) -> [u8; TCP_HEADER_LEN] {
    let mut buf = [0u8; TCP_HEADER_LEN];
    {
        let mut pkt = MutableTcpPacket::new(&mut buf).expect("buffer is large enough for TCP header");
        pkt.set_source(src_port);
        pkt.set_destination(dst_port);
        pkt.set_sequence(seq);
        pkt.set_acknowledgement(0);
        pkt.set_data_offset((TCP_HEADER_LEN / 4) as u8);
        pkt.set_flags(TcpFlags::SYN);
        // A realistic-but-conservative receive window, similar to common
        // OS defaults, so the SYN doesn't stand out as scanner-generated.
        pkt.set_window(64240);
        pkt.set_urgent_ptr(0);
        pkt.set_options(&[TcpOption::mss(1460)]);

        let checksum = ipv4_checksum(&pkt.to_immutable(), &src_ip, &dst_ip);
        pkt.set_checksum(checksum);
    }
    buf
}

/// Build a raw TCP ACK segment (no SYN) for ACK-scan firewall mapping.
/// Per RFC 793, a host receiving an ACK that doesn't belong to any real
/// connection responds with a RST whose sequence number equals the ACK
/// field we sent — that's the correlation hook the ACK-scan engine uses
/// to validate replies (see nmor_net::cookie::validate_ack_scan_reply).
pub fn build_ack_segment(
    src_ip: Ipv4Addr,
    dst_ip: Ipv4Addr,
    src_port: u16,
    dst_port: u16,
    ack_value: u32,
) -> [u8; TCP_HEADER_LEN] {
    let mut buf = [0u8; TCP_HEADER_LEN];
    {
        let mut pkt = MutableTcpPacket::new(&mut buf).expect("buffer is large enough for TCP header");
        pkt.set_source(src_port);
        pkt.set_destination(dst_port);
        pkt.set_sequence(0);
        pkt.set_acknowledgement(ack_value);
        pkt.set_data_offset((TCP_HEADER_LEN / 4) as u8);
        pkt.set_flags(TcpFlags::ACK);
        pkt.set_window(64240);
        pkt.set_urgent_ptr(0);
        pkt.set_options(&[TcpOption::nop(), TcpOption::nop()]);

        let checksum = ipv4_checksum(&pkt.to_immutable(), &src_ip, &dst_ip);
        pkt.set_checksum(checksum);
    }
    buf
}

#[cfg(test)]
mod tests {
    use super::*;
    use pnet::packet::tcp::TcpPacket;

    #[test]
    fn builds_valid_syn() {
        let src_ip = Ipv4Addr::new(10, 0, 0, 1);
        let dst_ip = Ipv4Addr::new(10, 0, 0, 2);
        let buf = build_syn_segment(src_ip, dst_ip, 33333, 80, 0x1234_5678);

        let pkt = TcpPacket::new(&buf).unwrap();
        assert_eq!(pkt.get_source(), 33333);
        assert_eq!(pkt.get_destination(), 80);
        assert_eq!(pkt.get_sequence(), 0x1234_5678);
        assert_eq!(pkt.get_flags(), TcpFlags::SYN);

        // checksum should be non-zero and internally consistent
        let recomputed = ipv4_checksum(&pkt, &src_ip, &dst_ip);
        assert_eq!(pkt.get_checksum(), recomputed);
    }

    #[test]
    fn builds_valid_ack() {
        let src_ip = Ipv4Addr::new(10, 0, 0, 1);
        let dst_ip = Ipv4Addr::new(10, 0, 0, 2);
        let buf = build_ack_segment(src_ip, dst_ip, 44444, 443, 0xABCD_EF01);

        let pkt = TcpPacket::new(&buf).unwrap();
        assert_eq!(pkt.get_source(), 44444);
        assert_eq!(pkt.get_destination(), 443);
        assert_eq!(pkt.get_acknowledgement(), 0xABCD_EF01);
        assert_eq!(pkt.get_flags(), TcpFlags::ACK);

        let recomputed = ipv4_checksum(&pkt, &src_ip, &dst_ip);
        assert_eq!(pkt.get_checksum(), recomputed);
    }
}
