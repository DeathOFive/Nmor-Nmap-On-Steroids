//! Auto-detect the local IPv4 address that would be used to reach a given
//! destination, via the classic "connect a UDP socket, never send anything,
//! read back local_addr()" trick. No packets actually leave the host for
//! this — UDP connect() just consults the routing table.

use std::net::{Ipv4Addr, SocketAddr, UdpSocket};

pub fn detect_source_ip(dst: Ipv4Addr) -> std::io::Result<Ipv4Addr> {
    let sock = UdpSocket::bind("0.0.0.0:0")?;
    sock.connect(SocketAddr::from((dst, 80)))?;
    match sock.local_addr()?.ip() {
        std::net::IpAddr::V4(v4) => Ok(v4),
        std::net::IpAddr::V6(_) => unreachable!("bound to V4, connected to V4 dst"),
    }
}
