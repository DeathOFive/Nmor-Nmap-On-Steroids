//! Adaptive pacing for outgoing SYN packets, AIMD-style (Additive Increase,
//! Multiplicative Decrease) — the same family of algorithm TCP congestion
//! control uses.
//!
//! IMPORTANT NUANCE: unlike TCP congestion control, we cannot perfectly
//! distinguish "the network/target is dropping our packets due to
//! congestion" from "these ports are simply filtered and were never going
//! to reply." Both look identical from here: silence. So this controller's
//! signal is deliberately coarse — it backs off when the *overall* reply
//! rate across the whole probe stream drops sharply, which in practice
//! tends to mean one of: we're saturating our own NIC/conntrack, a
//! middlebox is rate-limiting us, or the target is actively rate-limiting
//! RSTs/ICMP (a common anti-scan defense). It is NOT a measurement of "how
//! many ports are open." Treat it as a courtesy throttle, not a precision
//! instrument — and prefer `--rate` (fixed) over adaptive when you need
//! reproducible timing for a report.

use std::sync::atomic::{AtomicU64, Ordering};

pub struct AdaptiveRate {
    current_pps: AtomicU64,
    min_pps: u64,
    max_pps: u64,
}

const MIN_SAMPLE_SIZE: u64 = 30;
const LOW_REPLY_RATIO: f64 = 0.5;
const HIGH_REPLY_RATIO: f64 = 0.85;

impl AdaptiveRate {
    pub fn new(initial_pps: u64, min_pps: u64, max_pps: u64) -> Self {
        let initial = initial_pps.clamp(min_pps, max_pps);
        Self {
            current_pps: AtomicU64::new(initial),
            min_pps,
            max_pps,
        }
    }

    pub fn current_pps(&self) -> u64 {
        self.current_pps.load(Ordering::Relaxed)
    }

    /// Called periodically by the sender with counts observed over the most
    /// recent trailing window. Adjusts the rate up or down accordingly.
    /// Small windows are ignored (not enough signal to act on).
    pub fn observe_window(&self, sent_in_window: u64, replied_in_window: u64) {
        if sent_in_window < MIN_SAMPLE_SIZE {
            return;
        }
        let ratio = replied_in_window as f64 / sent_in_window as f64;

        if ratio < LOW_REPLY_RATIO {
            self.decrease();
        } else if ratio > HIGH_REPLY_RATIO {
            self.increase();
        }
        // Between the two thresholds: hold steady, no clear signal either way.
    }

    fn increase(&self) {
        let cur = self.current_pps();
        let step = (cur / 20).max(10); // +5%, min step of 10pps so we don't stall at low rates
        let next = cur.saturating_add(step).min(self.max_pps);
        self.current_pps.store(next, Ordering::Relaxed);
    }

    fn decrease(&self) {
        let cur = self.current_pps();
        let next = ((cur as f64) * 0.7).round() as u64;
        self.current_pps.store(next.max(self.min_pps), Ordering::Relaxed);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ignores_small_windows() {
        let r = AdaptiveRate::new(100, 10, 10000);
        r.observe_window(5, 0); // tiny window, should be ignored
        assert_eq!(r.current_pps(), 100);
    }

    #[test]
    fn backs_off_on_high_loss() {
        let r = AdaptiveRate::new(1000, 10, 10000);
        r.observe_window(100, 5); // 5% reply rate -> big loss signal
        assert!(r.current_pps() < 1000);
    }

    #[test]
    fn speeds_up_on_high_reply_rate() {
        let r = AdaptiveRate::new(100, 10, 10000);
        r.observe_window(100, 95); // 95% reply rate -> safe to go faster
        assert!(r.current_pps() > 100);
    }

    #[test]
    fn respects_min_and_max_bounds() {
        let r = AdaptiveRate::new(100, 50, 200);
        for _ in 0..50 {
            r.observe_window(100, 0);
        }
        assert_eq!(r.current_pps(), 50);

        let r2 = AdaptiveRate::new(100, 50, 200);
        for _ in 0..50 {
            r2.observe_window(100, 100);
        }
        assert_eq!(r2.current_pps(), 200);
    }
}
