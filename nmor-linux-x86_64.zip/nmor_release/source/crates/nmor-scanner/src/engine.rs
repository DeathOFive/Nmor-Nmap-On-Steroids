//! The scan engine: orchestrates a sender thread and a receiver thread
//! against a raw TCP socket pair, paced by an adaptive rate controller, and
//! aggregates results into a `nmor_core::ScanReport`.
//!
//! Threading model:
//!   - Sender thread: walks the full (ip, port) probe list, paces itself
//!     via `AdaptiveRate`, sends a SYN per probe, periodically reports its
//!     send-count to the rate controller's feedback loop.
//!   - Receiver thread: polls the raw socket in a loop with a short
//!     timeout (so it can notice shutdown promptly), validates each
//!     inbound packet's cookie, and forwards confirmed hits to the main
//!     thread over an mpsc channel.
//!   - Main thread: waits for the sender to finish, then waits a grace
//!     period for trailing replies, then signals the receiver to stop and
//!     assembles the final report (anything probed but never confirmed
//!     is reported Filtered).

use crate::rate::AdaptiveRate;
use nmor_core::{HostResult, PortResult, PortState, ScanReport};
use nmor_net::{initial_seq, open_raw_channel, random_secret, validate_reply, TcpReply};
use std::collections::HashMap;
use std::net::Ipv4Addr;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::mpsc;
use std::sync::Arc;
use std::thread;
use std::time::{Duration, Instant};

#[derive(Debug, Clone)]
pub struct ScanOptions {
    /// Fixed source port used for every probe in this run. A raw IPPROTO_TCP
    /// socket receives all inbound TCP traffic to the host, so we use this
    /// to cheaply recognize "is this reply addressed to us at all" before
    /// even checking the cookie.
    pub src_port: u16,
    /// Override auto-detected source IP (useful for multi-homed hosts).
    pub src_ip: Option<Ipv4Addr>,
    pub initial_pps: u64,
    pub min_pps: u64,
    pub max_pps: u64,
    /// How long after the sender finishes to keep listening for trailing
    /// replies before giving up on the remaining probes (-> Filtered).
    pub grace_period: Duration,
    /// Poll timeout used per recv call; lower = more responsive shutdown,
    /// higher = slightly less CPU spin. 100ms is a reasonable default.
    pub recv_poll_timeout: Duration,
}

impl Default for ScanOptions {
    fn default() -> Self {
        Self {
            src_port: 44321,
            src_ip: None,
            initial_pps: 100,
            min_pps: 10,
            max_pps: 50_000,
            grace_period: Duration::from_secs(3),
            recv_poll_timeout: Duration::from_millis(100),
        }
    }
}

#[derive(Debug, thiserror::Error)]
pub enum ScanError {
    #[error("no targets given")]
    NoTargets,
    #[error(transparent)]
    Channel(#[from] nmor_net::ChannelError),
    #[error("failed to auto-detect source IP: {0}")]
    SourceIpDetection(std::io::Error),
}

/// Internal message from receiver thread to main thread.
struct Hit {
    ip: Ipv4Addr,
    port: u16,
    state: PortState,
    rtt: Duration,
}

pub fn run_syn_scan(
    targets: &[Ipv4Addr],
    ports: &[u16],
    opts: &ScanOptions,
) -> Result<ScanReport, ScanError> {
    if targets.is_empty() || ports.is_empty() {
        return Err(ScanError::NoTargets);
    }

    let src_ip = match opts.src_ip {
        Some(ip) => ip,
        None => crate::source_ip::detect_source_ip(targets[0]).map_err(ScanError::SourceIpDetection)?,
    };

    let (mut sender, mut receiver) = open_raw_channel()?;
    let secret = random_secret();
    let src_port = opts.src_port;

    let total_probes: u64 = (targets.len() as u64) * (ports.len() as u64);

    let rate = Arc::new(AdaptiveRate::new(opts.initial_pps, opts.min_pps, opts.max_pps));
    let replies_seen = Arc::new(AtomicU64::new(0));
    let stop_flag = Arc::new(AtomicBool::new(false));
    let sender_done = Arc::new(AtomicBool::new(false));

    let (hit_tx, hit_rx) = mpsc::channel::<Hit>();

    // --- Receiver thread ---
    let recv_handle = {
        let stop_flag = stop_flag.clone();
        let replies_seen = replies_seen.clone();
        let poll_timeout = opts.recv_poll_timeout;
        thread::spawn(move || {
            while !stop_flag.load(Ordering::Relaxed) {
                if let Some(reply) = receiver.recv_one(poll_timeout) {
                    if let Some(hit) = process_reply(secret, src_port, &reply) {
                        replies_seen.fetch_add(1, Ordering::Relaxed);
                        // Receiver side closing first is fine; main thread
                        // keeps hit_rx alive until it's done collecting.
                        let _ = hit_tx.send(hit);
                    }
                }
            }
        })
    };

    // --- Sender thread ---
    let send_handle = {
        let rate = rate.clone();
        let replies_seen = replies_seen.clone();
        let sender_done = sender_done.clone();
        let stop_flag = stop_flag.clone();
        let targets = targets.to_vec();
        let ports = ports.to_vec();
        thread::spawn(move || {
            let mut sent_since_eval: u64 = 0;
            let mut replied_at_last_eval: u64 = 0;
            const EVAL_EVERY: u64 = 50;

            'outer: for &ip in &targets {
                for &port in &ports {
                    let seq = initial_seq(secret, src_port, ip, port);
                    // Best-effort send: a single dropped probe just becomes
                    // a Filtered/no-answer result, not a fatal error.
                    let _ = sender.send_syn(src_ip, ip, src_port, port, seq);

                    sent_since_eval += 1;
                    if sent_since_eval >= EVAL_EVERY {
                        let replied_now = replies_seen.load(Ordering::Relaxed);
                        let replied_in_window = replied_now.saturating_sub(replied_at_last_eval);
                        rate.observe_window(sent_since_eval, replied_in_window);
                        sent_since_eval = 0;
                        replied_at_last_eval = replied_now;
                    }

                    let pps = rate.current_pps().max(1);
                    thread::sleep(Duration::from_secs_f64(1.0 / pps as f64));

                    if stop_flag.load(Ordering::Relaxed) {
                        break 'outer;
                    }
                }
            }
            sender_done.store(true, Ordering::Relaxed);
        })
    };

    // --- Main thread: collect results as they arrive ---
    let mut results: HashMap<(Ipv4Addr, u16), (PortState, Duration)> = HashMap::new();
    let scan_start = Instant::now();

    // Drain hits while sender is running and during the grace period after.
    loop {
        match hit_rx.recv_timeout(Duration::from_millis(200)) {
            Ok(hit) => {
                results.insert((hit.ip, hit.port), (hit.state, hit.rtt));
            }
            Err(mpsc::RecvTimeoutError::Timeout) => {
                if sender_done.load(Ordering::Relaxed) {
                    // Sender's finished; give trailing replies `grace_period`
                    // from THIS point, then stop.
                    break;
                }
            }
            Err(mpsc::RecvTimeoutError::Disconnected) => break,
        }
    }

    let grace_deadline = Instant::now() + opts.grace_period;
    while Instant::now() < grace_deadline {
        match hit_rx.recv_timeout(Duration::from_millis(200)) {
            Ok(hit) => {
                results.insert((hit.ip, hit.port), (hit.state, hit.rtt));
            }
            Err(mpsc::RecvTimeoutError::Timeout) => continue,
            Err(mpsc::RecvTimeoutError::Disconnected) => break,
        }
    }

    stop_flag.store(true, Ordering::Relaxed);
    let _ = send_handle.join();
    let _ = recv_handle.join();

    let total_duration = scan_start.elapsed();
    let packets_received = replies_seen.load(Ordering::Relaxed);

    let mut hosts = Vec::with_capacity(targets.len());
    for &ip in targets {
        let mut host = HostResult::new(std::net::IpAddr::V4(ip));
        for &port in ports {
            let (state, rtt) = match results.get(&(ip, port)) {
                Some((state, rtt)) => (*state, Some(*rtt)),
                None => (PortState::Filtered, None),
            };
            host.ports.push(PortResult { port, state, rtt, banner: None });
        }
        hosts.push(host);
    }

    Ok(ScanReport {
        hosts,
        total_duration,
        packets_sent: total_probes,
        packets_received,
    })
}

/// Validate a raw reply's cookie and classify it into a port-state hit.
/// Returns None for replies that aren't addressed to us or don't validate
/// (this is the path that filters out noise, our own loopback echo, and
/// any spoofed/stray traffic).
fn process_reply(secret: nmor_net::Secret, our_src_port: u16, reply: &TcpReply) -> Option<Hit> {
    if reply.dst_port != our_src_port {
        return None;
    }
    if !validate_reply(secret, our_src_port, reply.src_ip, reply.src_port, reply.ack) {
        return None;
    }

    const RST: u8 = 0x04;
    const SYN: u8 = 0x02;
    const ACK: u8 = 0x10;

    let state = if reply.flags & SYN != 0 && reply.flags & ACK != 0 {
        PortState::Open
    } else if reply.flags & RST != 0 {
        PortState::Closed
    } else {
        return None; // unexpected flag combo; ignore rather than guess
    };

    Some(Hit {
        ip: reply.src_ip,
        port: reply.src_port,
        state,
        // RTT measurement against a real clock requires per-probe send
        // timestamps, which our stateless design intentionally doesn't
        // keep. v2 can add an optional timestamp side-table for users who
        // want RTT data and are OK with the memory cost.
        rtt: Duration::ZERO,
    })
}
