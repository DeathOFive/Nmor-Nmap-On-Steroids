//! TCP connect scan (-sT): the non-privileged scan technique. Instead of
//! crafting raw packets, this just asks the OS to complete a full TCP
//! handshake via connect(). No root needed, but it's noisier (a full
//! connection is logged by the target/any firewall) and slower per-probe
//! than the SYN scan's raw approach — the classic Nmap tradeoff.

use nmor_core::{HostResult, PortResult, PortState, ScanReport};
use std::net::{IpAddr, Ipv4Addr, SocketAddr, TcpStream};
use std::sync::mpsc;
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::{Duration, Instant};

#[derive(Debug, Clone)]
pub struct ConnectScanOptions {
    pub timeout: Duration,
    /// Number of worker threads making concurrent connect() calls.
    pub concurrency: usize,
}

impl Default for ConnectScanOptions {
    fn default() -> Self {
        Self {
            timeout: Duration::from_millis(800),
            concurrency: 256,
        }
    }
}

pub fn run_connect_scan(
    targets: &[Ipv4Addr],
    ports: &[u16],
    opts: &ConnectScanOptions,
) -> ScanReport {
    let probes: Vec<(Ipv4Addr, u16)> = targets
        .iter()
        .flat_map(|&ip| ports.iter().map(move |&p| (ip, p)))
        .collect();
    let total_probes = probes.len() as u64;

    let (work_tx, work_rx) = mpsc::channel::<(Ipv4Addr, u16)>();
    for probe in probes {
        let _ = work_tx.send(probe);
    }
    drop(work_tx);
    let work_rx = Arc::new(Mutex::new(work_rx));

    let (result_tx, result_rx) = mpsc::channel::<(Ipv4Addr, u16, PortState, Duration)>();
    let n_workers = opts.concurrency.max(1).min(total_probes.max(1) as usize);
    let timeout = opts.timeout;

    let start = Instant::now();
    let mut handles = Vec::with_capacity(n_workers);
    for _ in 0..n_workers {
        let work_rx = work_rx.clone();
        let result_tx = result_tx.clone();
        handles.push(thread::spawn(move || loop {
            let item = {
                let rx = work_rx.lock().expect("work queue mutex poisoned");
                rx.recv()
            };
            match item {
                Ok((ip, port)) => {
                    let probe_start = Instant::now();
                    let state = probe_connect(ip, port, timeout);
                    let rtt = probe_start.elapsed();
                    let _ = result_tx.send((ip, port, state, rtt));
                }
                Err(_) => break, // work queue drained
            }
        }));
    }
    drop(result_tx);

    let mut results: std::collections::HashMap<(Ipv4Addr, u16), (PortState, Duration)> =
        std::collections::HashMap::new();
    while let Ok((ip, port, state, rtt)) = result_rx.recv() {
        results.insert((ip, port), (state, rtt));
    }
    for h in handles {
        let _ = h.join();
    }
    let total_duration = start.elapsed();

    let mut hosts = Vec::with_capacity(targets.len());
    for &ip in targets {
        let mut host = HostResult::new(IpAddr::V4(ip));
        for &port in ports {
            let (state, rtt) = results
                .get(&(ip, port))
                .map(|(s, r)| (*s, Some(*r)))
                .unwrap_or((PortState::Filtered, None));
            host.ports.push(PortResult { port, state, rtt, banner: None });
        }
        hosts.push(host);
    }

    ScanReport {
        hosts,
        total_duration,
        packets_sent: total_probes, // not literal packets here, but probes attempted
        packets_received: results.len() as u64,
    }
}

fn probe_connect(ip: Ipv4Addr, port: u16, timeout: Duration) -> PortState {
    let addr = SocketAddr::new(IpAddr::V4(ip), port);
    match TcpStream::connect_timeout(&addr, timeout) {
        Ok(stream) => {
            drop(stream);
            PortState::Open
        }
        Err(e) => {
            use std::io::ErrorKind;
            match e.kind() {
                ErrorKind::ConnectionRefused => PortState::Closed,
                // Timeout, host unreachable, or anything else inconclusive:
                // treat as filtered, matching Nmap's connect-scan convention.
                _ => PortState::Filtered,
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::net::TcpListener;

    #[test]
    fn detects_open_and_closed() {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let open_port = listener.local_addr().unwrap().port();
        // Pick a port almost certainly closed.
        let closed_port = 54999u16;

        let targets = vec![Ipv4Addr::new(127, 0, 0, 1)];
        let ports = vec![open_port, closed_port];
        let opts = ConnectScanOptions {
            timeout: Duration::from_millis(500),
            concurrency: 4,
        };

        let report = run_connect_scan(&targets, &ports, &opts);
        let host = &report.hosts[0];
        let get_state = |p: u16| host.ports.iter().find(|pr| pr.port == p).unwrap().state;

        assert_eq!(get_state(open_port), PortState::Open);
        assert_eq!(get_state(closed_port), PortState::Closed);
    }
}
