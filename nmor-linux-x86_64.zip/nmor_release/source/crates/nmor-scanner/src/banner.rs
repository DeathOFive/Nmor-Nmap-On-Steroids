//! Lightweight service/banner detection (-sV). This is NOT a reimplementation
//! of Nmap's nmap-service-probes database (thousands of versioned probes
//! across hundreds of protocols) — it's a much smaller, honest version:
//! connect, optionally nudge with a generic protocol-appropriate probe, and
//! report whatever the service says first. Good enough to identify "this is
//! an SSH server running OpenSSH 8.9" or "this is nginx," not good enough
//! to replace Nmap's version-detection database for obscure protocols.

use nmor_core::{HostResult, PortState};
use std::io::{Read, Write};
use std::net::{IpAddr, SocketAddr, TcpStream};
use std::time::Duration;

/// Ports where the service waits for the client to speak first; we send a
/// minimal nudge before reading, otherwise we'd just block until our
/// connect-side timeout with nothing to show for it.
const CLIENT_SPEAKS_FIRST: &[u16] = &[80, 443, 8080, 8000, 8008, 8443, 8888, 3000];

/// Grab banners for every Open port across all hosts, mutating the report
/// in place. Uses one thread per open port (open-port counts are typically
/// small, so a full thread pool would be overkill here).
pub fn grab_banners(hosts: &mut [HostResult], timeout: Duration) {
    let mut targets: Vec<(usize, usize, IpAddr, u16)> = Vec::new();
    for (hi, host) in hosts.iter().enumerate() {
        for (pi, port) in host.ports.iter().enumerate() {
            if port.state == PortState::Open {
                targets.push((hi, pi, host.ip, port.port));
            }
        }
    }
    if targets.is_empty() {
        return;
    }

    let results: Vec<(usize, usize, Option<String>)> = std::thread::scope(|scope| {
        let handles: Vec<_> = targets
            .into_iter()
            .map(|(hi, pi, ip, port)| {
                scope.spawn(move || (hi, pi, grab_one_banner(ip, port, timeout)))
            })
            .collect();
        handles.into_iter().map(|h| h.join().unwrap()).collect()
    });

    for (hi, pi, banner) in results {
        hosts[hi].ports[pi].banner = banner;
    }
}

fn grab_one_banner(ip: IpAddr, port: u16, timeout: Duration) -> Option<String> {
    let addr = SocketAddr::new(ip, port);
    let mut stream = TcpStream::connect_timeout(&addr, timeout).ok()?;
    let _ = stream.set_read_timeout(Some(timeout));
    let _ = stream.set_write_timeout(Some(timeout));

    if CLIENT_SPEAKS_FIRST.contains(&port) {
        let _ = stream.write_all(b"HEAD / HTTP/1.0\r\n\r\n");
    }

    let mut buf = [0u8; 256];
    let n = stream.read(&mut buf).ok()?;
    if n == 0 {
        return None;
    }
    Some(sanitize_banner(&buf[..n]))
}

/// Strip the banner down to printable ASCII and a sane length — never hand
/// raw service-controlled bytes to a terminal or output file.
fn sanitize_banner(bytes: &[u8]) -> String {
    let s: String = bytes
        .iter()
        .take(120)
        .map(|&b| if b.is_ascii_graphic() || b == b' ' { b as char } else { '.' })
        .collect();
    s.trim().to_string()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sanitize_strips_control_chars() {
        let raw = b"SSH-2.0-OpenSSH_9.6\r\nfoo\x00bar";
        let s = sanitize_banner(raw);
        assert!(s.starts_with("SSH-2.0-OpenSSH_9.6"));
        assert!(!s.contains('\r'));
        assert!(!s.contains('\0'));
    }
}
