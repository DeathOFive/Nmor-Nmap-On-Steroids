//! TCP ACK scan (-sA): sends bare ACK segments to map firewall rulesets.
//! Per RFC 793, any host whose TCP stack is up will RST an out-of-context
//! ACK regardless of whether the port is "open" in the application sense —
//! so a RST means *unfiltered* (a stateless firewall isn't dropping packets
//! to this port), and silence means *filtered*. This deliberately cannot
//! tell you whether a service is actually listening — that's not what an
//! ACK scan is for; pair it with -sS for that.

use crate::rate::AdaptiveRate;
use nmor_core::{HostResult, PortResult, PortState, ScanReport};
use nmor_net::{open_raw_channel, random_secret, validate_ack_scan_reply, TcpReply};
use std::net::Ipv4Addr;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::mpsc;
use std::sync::Arc;
use std::thread;
use std::time::{Duration, Instant};

pub use crate::engine::ScanOptions as AckScanOptions;

struct Hit {
    ip: Ipv4Addr,
    port: u16,
}

pub fn run_ack_scan(
    targets: &[Ipv4Addr],
    ports: &[u16],
    opts: &AckScanOptions,
) -> Result<ScanReport, crate::engine::ScanError> {
    use crate::engine::ScanError;

    if targets.is_empty() || ports.is_empty() {
        return Err(ScanError::NoTargets);
    }

    let src_ip = match opts.src_ip {
        Some(ip) => ip,
        None => {
            crate::source_ip::detect_source_ip(targets[0]).map_err(ScanError::SourceIpDetection)?
        }
    };

    let (mut sender, mut receiver) = open_raw_channel()?;
    let secret = random_secret();
    let src_port = opts.src_port;
    let total_probes: u64 = (targets.len() as u64) * (ports.len() as u64);

    let rate = Arc::new(AdaptiveRate::new(opts.initial_pps, opts.min_pps, opts.max_pps));
    let replies_seen = Arc::new(AtomicU64::new(0));
    let stop_flag = Arc::new(AtomicBool::new(false));
    let sender_done = Arc::new(AtomicBool::new(false));

    let (hit_tx, hit_rx) = mpsc::channel::<Hit>();

    let recv_handle = {
        let stop_flag = stop_flag.clone();
        let replies_seen = replies_seen.clone();
        let poll_timeout = opts.recv_poll_timeout;
        thread::spawn(move || {
            while !stop_flag.load(Ordering::Relaxed) {
                if let Some(reply) = receiver.recv_one(poll_timeout) {
                    if let Some(hit) = process_ack_reply(secret, src_port, &reply) {
                        replies_seen.fetch_add(1, Ordering::Relaxed);
                        let _ = hit_tx.send(hit);
                    }
                }
            }
        })
    };

    let send_handle = {
        let rate = rate.clone();
        let replies_seen = replies_seen.clone();
        let sender_done = sender_done.clone();
        let stop_flag = stop_flag.clone();
        let targets = targets.to_vec();
        let ports = ports.to_vec();
        thread::spawn(move || {
            let mut sent_since_eval: u64 = 0;
            let mut replied_at_last_eval: u64 = 0;
            const EVAL_EVERY: u64 = 50;

            'outer: for &ip in &targets {
                for &port in &ports {
                    let cookie = nmor_net::initial_seq(secret, src_port, ip, port);
                    let _ = sender.send_ack(src_ip, ip, src_port, port, cookie);

                    sent_since_eval += 1;
                    if sent_since_eval >= EVAL_EVERY {
                        let replied_now = replies_seen.load(Ordering::Relaxed);
                        let replied_in_window = replied_now.saturating_sub(replied_at_last_eval);
                        rate.observe_window(sent_since_eval, replied_in_window);
                        sent_since_eval = 0;
                        replied_at_last_eval = replied_now;
                    }

                    let pps = rate.current_pps().max(1);
                    thread::sleep(Duration::from_secs_f64(1.0 / pps as f64));

                    if stop_flag.load(Ordering::Relaxed) {
                        break 'outer;
                    }
                }
            }
            sender_done.store(true, Ordering::Relaxed);
        })
    };

    let mut hit_set: std::collections::HashSet<(Ipv4Addr, u16)> = std::collections::HashSet::new();
    let scan_start = Instant::now();

    loop {
        match hit_rx.recv_timeout(Duration::from_millis(200)) {
            Ok(hit) => {
                hit_set.insert((hit.ip, hit.port));
            }
            Err(mpsc::RecvTimeoutError::Timeout) => {
                if sender_done.load(Ordering::Relaxed) {
                    break;
                }
            }
            Err(mpsc::RecvTimeoutError::Disconnected) => break,
        }
    }

    let grace_deadline = Instant::now() + opts.grace_period;
    while Instant::now() < grace_deadline {
        match hit_rx.recv_timeout(Duration::from_millis(200)) {
            Ok(hit) => {
                hit_set.insert((hit.ip, hit.port));
            }
            Err(mpsc::RecvTimeoutError::Timeout) => continue,
            Err(mpsc::RecvTimeoutError::Disconnected) => break,
        }
    }

    stop_flag.store(true, Ordering::Relaxed);
    let _ = send_handle.join();
    let _ = recv_handle.join();

    let total_duration = scan_start.elapsed();
    let packets_received = replies_seen.load(Ordering::Relaxed);

    let mut hosts = Vec::with_capacity(targets.len());
    for &ip in targets {
        let mut host = HostResult::new(std::net::IpAddr::V4(ip));
        for &port in ports {
            let state = if hit_set.contains(&(ip, port)) {
                PortState::Unfiltered
            } else {
                PortState::Filtered
            };
            host.ports.push(PortResult { port, state, rtt: None, banner: None });
        }
        hosts.push(host);
    }

    Ok(ScanReport {
        hosts,
        total_duration,
        packets_sent: total_probes,
        packets_received,
    })
}

fn process_ack_reply(secret: nmor_net::Secret, our_src_port: u16, reply: &TcpReply) -> Option<Hit> {
    if reply.dst_port != our_src_port {
        return None;
    }
    const RST: u8 = 0x04;
    if reply.flags & RST == 0 {
        return None;
    }
    if !validate_ack_scan_reply(secret, our_src_port, reply.src_ip, reply.src_port, reply.seq) {
        return None;
    }
    Some(Hit { ip: reply.src_ip, port: reply.src_port })
}
