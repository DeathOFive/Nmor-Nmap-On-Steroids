use nmor_scanner::ack_scan::AckScanOptions;
use nmor_scanner::run_ack_scan;
use std::net::{Ipv4Addr, TcpListener};
use std::time::Duration;

fn main() {
    let listener = TcpListener::bind("127.0.0.1:0").unwrap();
    let open_port = listener.local_addr().unwrap().port();
    let closed_port = 54999u16;

    println!("ACK-scanning open_port={open_port} (listening) and closed_port={closed_port}");

    let targets = vec![Ipv4Addr::new(127, 0, 0, 1)];
    let ports = vec![open_port, closed_port];
    let opts = AckScanOptions {
        src_port: 47000,
        grace_period: Duration::from_secs(2),
        ..Default::default()
    };

    let report = run_ack_scan(&targets, &ports, &opts).expect("ack scan failed");

    let mut ok = true;
    for host in &report.hosts {
        for pr in &host.ports {
            println!("  {}/tcp {}", pr.port, pr.state);
            // On loopback with no firewall, BOTH should come back as
            // "unfiltered" — RFC793 says any reachable TCP stack RSTs an
            // out-of-context ACK whether or not anything is listening on
            // that port. That's the whole point of an ACK scan: it tells
            // you about firewall presence, not service presence.
            if pr.state != nmor_core::PortState::Unfiltered {
                ok = false;
                println!("    ^^^ expected Unfiltered, got {:?}", pr.state);
            }
        }
    }

    if ok {
        println!("SUCCESS: both ports correctly reported unfiltered");
    } else {
        println!("FAILURE");
        std::process::exit(1);
    }
}
