use nmor_scanner::{run_syn_scan, ScanOptions};
use std::net::{Ipv4Addr, TcpListener};

fn main() {
    // Stand up listeners on a few ports; leave others deliberately closed.
    let mut listeners = vec![];
    let mut open_ports = vec![];
    for _ in 0..3 {
        let l = TcpListener::bind("127.0.0.1:0").unwrap();
        open_ports.push(l.local_addr().unwrap().port());
        listeners.push(l); // keep alive so it stays listening
    }
    open_ports.sort_unstable();

    // Build a port list: the open ones, plus some ports almost certainly closed.
    let mut ports: Vec<u16> = open_ports.clone();
    ports.extend_from_slice(&[55001, 55002, 55003, 55004, 55005]);
    ports.sort_unstable();

    println!("open ports under test: {open_ports:?}");
    println!("full port list: {ports:?}");

    let targets = vec![Ipv4Addr::new(127, 0, 0, 1)];
    let opts = ScanOptions {
        src_port: 47777,
        initial_pps: 200,
        grace_period: std::time::Duration::from_secs(2),
        ..Default::default()
    };

    let report = run_syn_scan(&targets, &ports, &opts).expect("scan failed");

    println!(
        "\nscan done in {:?}, sent={}, received={}",
        report.total_duration, report.packets_sent, report.packets_received
    );

    let mut all_correct = true;
    for host in &report.hosts {
        println!("host {}:", host.ip);
        for pr in &host.ports {
            println!("  {}/tcp {}", pr.port, pr.state);
            let should_be_open = open_ports.contains(&pr.port);
            let is_open = pr.state == nmor_core::PortState::Open;
            if should_be_open != is_open {
                all_correct = false;
                println!("    ^^^ MISMATCH: expected open={should_be_open}, got {is_open}");
            }
        }
    }

    if all_correct {
        println!("\nSUCCESS: all port states matched expectations");
    } else {
        println!("\nFAILURE: some port states were wrong");
        std::process::exit(1);
    }
}
