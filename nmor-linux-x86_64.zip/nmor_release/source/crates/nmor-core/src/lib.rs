//! nmor-core: shared types and pure parsing logic used by every other Nmor crate.
//! No networking, no raw sockets here — just data types and parsers, so this
//! crate stays trivially testable and reusable (e.g. by a future GUI front-end).

pub mod port;
pub mod result;
pub mod target;

pub use port::{parse_ports, PortParseError, TOP_100_PORTS};
pub use result::{HostResult, PortResult, PortState, ScanReport};
pub use target::{parse_target_list, parse_targets, TargetParseError};
