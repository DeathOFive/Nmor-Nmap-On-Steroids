//! Target specification parsing: single IPs, CIDR ranges, and IP ranges (a.b.c.d-e).
//!
//! Hostname resolution is intentionally NOT done here — nmor-core stays
//! dependency-light and pure. The CLI layer resolves hostnames via DNS
//! and feeds resulting IPs in as `Target::Ip` directly.

use ipnetwork::IpNetwork;
use std::net::{IpAddr, Ipv4Addr};
use std::str::FromStr;
use thiserror::Error;

#[derive(Debug, Error, PartialEq, Eq)]
pub enum TargetParseError {
    #[error("'{0}' is not a valid IP address, CIDR block, or IP range")]
    InvalidFormat(String),
    #[error("range '{0}' is invalid: start address is greater than end address")]
    InvalidRange(String),
    #[error("range '{0}' spans more than {1} addresses (use a smaller range or a CIDR block)")]
    RangeTooLarge(String, u64),
}

/// The maximum number of addresses we'll expand a literal a.b.c.d-e range into.
/// CIDR blocks are exempt from this (they're iterated lazily), but a typo'd
/// range like 10.0.0.0-255.255.255.255 should fail fast, not eat all your RAM.
const MAX_RANGE_EXPANSION: u64 = 1_000_000;

/// A single resolved scan target: one IP address.
/// Parsing functions below expand CIDR/range specs down to a flat Vec<IpAddr>.
pub fn parse_targets(spec: &str) -> Result<Vec<IpAddr>, TargetParseError> {
    let spec = spec.trim();

    // Plain single IP (v4 or v6)
    if let Ok(ip) = IpAddr::from_str(spec) {
        return Ok(vec![ip]);
    }

    // CIDR notation: 10.0.0.0/24
    if let Ok(net) = IpNetwork::from_str(spec) {
        return Ok(net.iter().collect());
    }

    // Dash range notation: 10.0.0.1-10.0.0.254  OR shorthand 10.0.0.1-254
    if let Some((start_str, end_str)) = spec.split_once('-') {
        return parse_ipv4_range(spec, start_str, end_str);
    }

    Err(TargetParseError::InvalidFormat(spec.to_string()))
}

fn parse_ipv4_range(
    original: &str,
    start_str: &str,
    end_str: &str,
) -> Result<Vec<IpAddr>, TargetParseError> {
    let start = Ipv4Addr::from_str(start_str.trim())
        .map_err(|_| TargetParseError::InvalidFormat(original.to_string()))?;

    // Shorthand support: "10.0.0.1-254" means last octet ranges 1..=254
    let end = if let Ok(last_octet) = end_str.trim().parse::<u8>() {
        let o = start.octets();
        Ipv4Addr::new(o[0], o[1], o[2], last_octet)
    } else {
        Ipv4Addr::from_str(end_str.trim())
            .map_err(|_| TargetParseError::InvalidFormat(original.to_string()))?
    };

    let start_u32 = u32::from(start);
    let end_u32 = u32::from(end);

    if start_u32 > end_u32 {
        return Err(TargetParseError::InvalidRange(original.to_string()));
    }

    let span = (end_u32 - start_u32) as u64 + 1;
    if span > MAX_RANGE_EXPANSION {
        return Err(TargetParseError::RangeTooLarge(
            original.to_string(),
            MAX_RANGE_EXPANSION,
        ));
    }

    Ok((start_u32..=end_u32)
        .map(|n| IpAddr::V4(Ipv4Addr::from(n)))
        .collect())
}

/// Parse multiple comma-separated target specs, e.g. "10.0.0.1,10.0.0.0/24,192.168.1.1-50"
pub fn parse_target_list(specs: &str) -> Result<Vec<IpAddr>, TargetParseError> {
    let mut out = Vec::new();
    for part in specs.split(',') {
        let part = part.trim();
        if part.is_empty() {
            continue;
        }
        out.extend(parse_targets(part)?);
    }
    Ok(out)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn single_ip() {
        assert_eq!(
            parse_targets("192.168.1.1").unwrap(),
            vec![IpAddr::V4(Ipv4Addr::new(192, 168, 1, 1))]
        );
    }

    #[test]
    fn cidr_slash_30() {
        let ips = parse_targets("10.0.0.0/30").unwrap();
        assert_eq!(ips.len(), 4);
    }

    #[test]
    fn shorthand_range() {
        let ips = parse_targets("10.0.0.1-5").unwrap();
        assert_eq!(ips.len(), 5);
        assert_eq!(ips[0], IpAddr::V4(Ipv4Addr::new(10, 0, 0, 1)));
        assert_eq!(ips[4], IpAddr::V4(Ipv4Addr::new(10, 0, 0, 5)));
    }

    #[test]
    fn full_range() {
        let ips = parse_targets("10.0.0.1-10.0.0.3").unwrap();
        assert_eq!(ips.len(), 3);
    }

    #[test]
    fn invalid_range_backwards() {
        let err = parse_targets("10.0.0.10-10.0.0.1").unwrap_err();
        assert_eq!(err, TargetParseError::InvalidRange("10.0.0.10-10.0.0.1".to_string()));
    }

    #[test]
    fn garbage_input() {
        assert!(parse_targets("not-an-ip").is_err());
    }

    #[test]
    fn comma_list() {
        let ips = parse_target_list("10.0.0.1, 10.0.0.2,10.0.0.0/30").unwrap();
        assert_eq!(ips.len(), 6);
    }
}
