//! Result types produced by a scan: per-port state and per-host aggregation.

use serde::{Deserialize, Serialize};
use std::net::IpAddr;
use std::time::Duration;

/// The state of a single scanned port, following Nmap's classic taxonomy.
///
/// For a raw SYN scan, the mapping from observed reply to state is:
///   - SYN/ACK received      -> Open
///   - RST received          -> Closed
///   - No reply (timeout)    -> Filtered (firewall silently dropped it)
///   - ICMP unreachable      -> Filtered
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum PortState {
    Open,
    Closed,
    Filtered,
    /// Couldn't distinguish open vs filtered (used by scan types other than SYN,
    /// kept here so the type is shared and future scan modes can reuse it).
    #[serde(rename = "open|filtered")]
    OpenFiltered,
    /// ACK-scan result: a RST came back, meaning the port isn't blocked by a
    /// simple stateless firewall rule. Says nothing about open vs closed —
    /// that's the whole point of an ACK scan (firewall ruleset mapping).
    Unfiltered,
}

impl std::fmt::Display for PortState {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let s = match self {
            PortState::Open => "open",
            PortState::Closed => "closed",
            PortState::Filtered => "filtered",
            PortState::OpenFiltered => "open|filtered",
            PortState::Unfiltered => "unfiltered",
        };
        write!(f, "{s}")
    }
}

/// Result for a single (host, port) pair.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PortResult {
    pub port: u16,
    pub state: PortState,
    /// Round-trip time of the response that determined this state, if any.
    pub rtt: Option<Duration>,
    /// First bytes read back from the service on this port, if a banner
    /// grab was performed (-sV) and the connection yielded any data.
    /// Sanitized to printable ASCII and truncated — never raw bytes.
    pub banner: Option<String>,
}

/// All results for a single scanned host.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HostResult {
    pub ip: IpAddr,
    pub ports: Vec<PortResult>,
}

impl HostResult {
    pub fn new(ip: IpAddr) -> Self {
        Self {
            ip,
            ports: Vec::new(),
        }
    }

    pub fn open_ports(&self) -> impl Iterator<Item = &PortResult> {
        self.ports.iter().filter(|p| p.state == PortState::Open)
    }
}

/// Aggregate result for an entire scan run across all targets.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScanReport {
    pub hosts: Vec<HostResult>,
    pub total_duration: Duration,
    pub packets_sent: u64,
    pub packets_received: u64,
}
