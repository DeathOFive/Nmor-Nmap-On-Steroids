//! Port specification parsing: "80", "22,80,443", "1-1024", "1-1000,8080,8443"

use thiserror::Error;

#[derive(Debug, Error, PartialEq, Eq)]
pub enum PortParseError {
    #[error("'{0}' is not a valid port or port range")]
    InvalidFormat(String),
    #[error("port {0} is out of range (must be 1-65535)")]
    OutOfRange(u32),
}

/// Parse a port spec like "22,80,443,8000-9000" into a sorted, deduplicated Vec<u16>.
/// Also supports Nmap-style open-ended shorthand: "-" (all 65535 ports),
/// "-1024" (1 through 1024), "1024-" (1024 through 65535).
pub fn parse_ports(spec: &str) -> Result<Vec<u16>, PortParseError> {
    let mut ports: Vec<u16> = Vec::new();

    for part in spec.split(',') {
        let part = part.trim();
        if part.is_empty() {
            continue;
        }

        // Bare "-" means the full port range, Nmap's "-p-" shorthand.
        if part == "-" {
            ports.extend(1u16..=65535u16);
            continue;
        }

        if let Some(stripped) = part.strip_prefix('-') {
            // "-1024" -> 1 through 1024
            let hi: u32 = stripped
                .trim()
                .parse()
                .map_err(|_| PortParseError::InvalidFormat(part.to_string()))?;
            validate_port(hi)?;
            ports.extend(1u16..=(hi as u16));
            continue;
        }

        if let Some(stripped) = part.strip_suffix('-') {
            // "1024-" -> 1024 through 65535
            let lo: u32 = stripped
                .trim()
                .parse()
                .map_err(|_| PortParseError::InvalidFormat(part.to_string()))?;
            validate_port(lo)?;
            ports.extend((lo as u16)..=65535u16);
            continue;
        }

        if let Some((lo, hi)) = part.split_once('-') {
            let lo: u32 = lo
                .trim()
                .parse()
                .map_err(|_| PortParseError::InvalidFormat(part.to_string()))?;
            let hi: u32 = hi
                .trim()
                .parse()
                .map_err(|_| PortParseError::InvalidFormat(part.to_string()))?;

            validate_port(lo)?;
            validate_port(hi)?;

            if lo > hi {
                return Err(PortParseError::InvalidFormat(part.to_string()));
            }

            ports.extend((lo as u16)..=(hi as u16));
        } else {
            let p: u32 = part
                .parse()
                .map_err(|_| PortParseError::InvalidFormat(part.to_string()))?;
            validate_port(p)?;
            ports.push(p as u16);
        }
    }

    if ports.is_empty() {
        return Err(PortParseError::InvalidFormat(spec.to_string()));
    }

    ports.sort_unstable();
    ports.dedup();
    Ok(ports)
}

fn validate_port(p: u32) -> Result<(), PortParseError> {
    if p == 0 || p > 65535 {
        Err(PortParseError::OutOfRange(p))
    } else {
        Ok(())
    }
}

/// A curated top-100 most-commonly-open ports for the `--top-ports` fast path,
/// mirroring nmap-services frequency ordering for the most common services.
pub const TOP_100_PORTS: [u16; 100] = [
    80, 23, 443, 21, 22, 25, 3389, 110, 445, 139, 143, 53, 135, 3306, 8080, 1723, 111, 995, 993,
    5900, 1025, 587, 8888, 199, 1720, 465, 548, 113, 81, 6001, 10000, 514, 5060, 179, 1026, 2000,
    8443, 8000, 32768, 554, 26, 1433, 49152, 2001, 515, 8008, 49154, 1027, 5666, 646, 5000, 5631,
    631, 49153, 8081, 2049, 88, 79, 5800, 106, 2121, 1110, 49155, 6000, 513, 990, 5357, 427,
    49156, 543, 544, 5101, 144, 7, 389, 8009, 3128, 444, 9999, 5009, 7070, 5190, 3000, 5432,
    1900, 3986, 13, 1029, 9, 6646, 5051, 49157, 1028, 873, 1755, 2717, 4899, 9100, 119, 37,
];

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn single_port() {
        assert_eq!(parse_ports("80").unwrap(), vec![80]);
    }

    #[test]
    fn list() {
        assert_eq!(parse_ports("22,80,443").unwrap(), vec![22, 80, 443]);
    }

    #[test]
    fn range() {
        assert_eq!(parse_ports("1-5").unwrap(), vec![1, 2, 3, 4, 5]);
    }

    #[test]
    fn mixed_dedup_and_sort() {
        assert_eq!(
            parse_ports("443,1-3,80,2").unwrap(),
            vec![1, 2, 3, 80, 443]
        );
    }

    #[test]
    fn zero_is_invalid() {
        assert!(parse_ports("0").is_err());
    }

    #[test]
    fn too_high_is_invalid() {
        assert!(parse_ports("65536").is_err());
    }

    #[test]
    fn backwards_range_is_invalid() {
        assert!(parse_ports("100-50").is_err());
    }

    #[test]
    fn dash_all_ports() {
        let p = parse_ports("-").unwrap();
        assert_eq!(p.len(), 65535);
        assert_eq!(p[0], 1);
        assert_eq!(p[p.len() - 1], 65535);
    }

    #[test]
    fn dash_open_low() {
        // "-1024" => 1 through 1024
        let p = parse_ports("-1024").unwrap();
        assert_eq!(p.len(), 1024);
        assert_eq!(p[0], 1);
        assert_eq!(*p.last().unwrap(), 1024);
    }

    #[test]
    fn dash_open_high() {
        // "65530-" => 65530 through 65535
        let p = parse_ports("65530-").unwrap();
        assert_eq!(p, vec![65530, 65531, 65532, 65533, 65534, 65535]);
    }
}
