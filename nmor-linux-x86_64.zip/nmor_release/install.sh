#!/usr/bin/env bash
# Nmor installer — copies the prebuilt binary into place and grants it
# raw-socket capability so you don't need `sudo` for every single scan.
set -euo pipefail

OS="$(uname -s)"
ARCH="$(uname -m)"

if [ "$OS" != "Linux" ]; then
    echo "error: nmor only supports Linux right now (detected: $OS)." >&2
    echo "On Windows, install WSL2 and run this script inside it." >&2
    exit 1
fi

if [ "$ARCH" != "x86_64" ]; then
    echo "error: this prebuilt binary is x86_64 only (detected: $ARCH)." >&2
    echo "Build from source instead — see README.md." >&2
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN_SRC="$SCRIPT_DIR/bin/nmor"
DEST="/usr/local/bin/nmor"

if [ ! -f "$BIN_SRC" ]; then
    echo "error: couldn't find the bundled binary at $BIN_SRC" >&2
    echo "Did you extract the whole release archive (not just this script)?" >&2
    exit 1
fi

echo "Installing nmor to $DEST (you'll be asked for your password)..."
sudo install -m 755 "$BIN_SRC" "$DEST"

if command -v setcap >/dev/null 2>&1; then
    echo "Granting CAP_NET_RAW so you can run nmor without sudo every time..."
    if sudo setcap cap_net_raw+ep "$DEST"; then
        echo ""
        echo "Installed. Try it right now, no sudo needed:"
        echo "  nmor -sS scanme.nmap.org -p 22,80,443"
    else
        echo "setcap failed — you'll need to prefix scans with sudo instead:"
        echo "  sudo nmor -sS scanme.nmap.org -p 22,80,443"
    fi
else
    echo "setcap not found (install it with: sudo apt install libcap2-bin)."
    echo "Until then, run scans with sudo:"
    echo "  sudo nmor -sS scanme.nmap.org -p 22,80,443"
fi

echo ""
echo "Note: -sT (TCP connect scan) never needs root/capabilities at all:"
echo "  nmor -sT scanme.nmap.org -p 22,80,443"
